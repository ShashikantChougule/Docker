package com.training.boot.ms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Example;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.boot.ms.dao.CurrencyConversionRepository;
import com.training.boot.ms.model.CurrencyConverter;

@RestController
@RequestMapping(value = "/api/v1")
@RefreshScope
public class CurrencyConverterController {
	
	Logger logger = LoggerFactory.getLogger(CurrencyConverterController.class);
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CurrencyConversionRepository repository;

	@Value("${app.message}")
	private String message;
	
	@RequestMapping(value = "/from/{from}/to/{to}")
	public CurrencyConverter convertCurrency(@PathVariable String from, @PathVariable String to) {

		CurrencyConverter converter = new CurrencyConverter(null, from, to, null);
		Example<CurrencyConverter> conversionFilter = Example.of(converter);
		
		   CurrencyConverter returnObject = repository.findOne(conversionFilter).get();
		   returnObject.setEnvironment(env.getProperty("server.port"));
		   logger.info("Currencyconverter" + returnObject.getEnvironment());
		   return returnObject;
		   
	}
	
	@GetMapping("/message")
	public String message() {
		return this.message;
	}
}
