package com.training.boot.ms.springcloudnetflixeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudNetflixEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
